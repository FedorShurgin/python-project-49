### Hexlet tests and linter status:
[![Actions Status](https://github.com/FedorShurgin/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/FedorShurgin/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/3b04109cd860de6fdd57/maintainability)](https://codeclimate.com/github/FedorShurgin/python-project-49/maintainability)